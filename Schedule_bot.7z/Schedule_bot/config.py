import logging
import os


USERDATA_PATH = r"backup/userdata"
CONVERSATIONS_PATH = r"backup/conversations"

PG_CONN = {
    'host': 'localhost',
    'port': 5432,
    'user': 'bot',
    'password': 1236,
    'autorollback': True
}

TOKENS = {
    'TEST': '505805791:AAE_9oldozU0CiYWcTnKa_Y-crr9cSCFE_I',
    'PROD': ''
}


ADMINS = ()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

LOGGING_LEVEL = logging.INFO
