from bot.models.models import Lecturers, Lessons, MyRetryDB, Users

TABLES = (Users, Lessons, Lecturers)
